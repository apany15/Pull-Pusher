#pragma once
#include"classModelRenderer.h"
//#include"classMS3DModel.h"
namespace MY_NS_V2
{
	class classMS3DModelOGLRenderer: public classModelRenderer
	{
	protected:
		bool vRender(classModel *m, float x, float y);
		//bool vRenderer(classMS3DModel *m, float x, float y);
		//bool MY_NS_V2::classModelRenderer::vRender(classMS3DModel *m, float x, float y);
		//virtual bool vRender(float x, float y);
	};
}