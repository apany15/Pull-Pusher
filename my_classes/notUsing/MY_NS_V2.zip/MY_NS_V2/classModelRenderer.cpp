#include"classModelRenderer.h"
#include"MY_NS_V2.h"
namespace MY_NS_V2
{
	//classModelRenderer::classModelRenderer(classModel *m)
	//	:model(m)
	//{
	//	if (model) model->RegMessReceiver(this);
	//}
	//void classModelRenderer::ConnectModel(classModel *m)
	//{
	//	if (model) model->UnRegMessReceiver(this);
	//	model=m;
	//	if (model) model->RegMessReceiver(this);
	//}
	//bool classModelRenderer::IsModelConnected()
	//{
	//	return (model==0 ? false : true);
	//}
	//bool classModelRenderer::Render(float x, float y)
	//{
	//	if (!IsModelConnected()) return false;
	//	return vRender(x,y);
	//}
	
	//void classModelRenderer::MessageReseive(int _message, MY_NS_MESSAGE::classMessageSender<int> * fromWho)
	//{
	//	if (fromWho==(MY_NS_MESSAGE::classMessageSender<int> *)model && _message==MESS_DIE) model=0;
	//}
	
}