#pragma once
#define TRANSPARENCY_MODE_SIMPLE				0
//#define TRANSPARENCY_MODE_DEPTHSORTEDTRIANGLES	1
//#define TRANSPARENCY_MODE_ALPHAREF				2

#define MAX_TEXTURE_FILENAME_SIZE	128

#include<vector>
#include"classModel.h"

namespace MY_NS_V2
{
	
	class classMS3DModel: public classModel
	{
	public:
		struct ms3d_vertex_t
		{
			unsigned char flags;
			float vertex[3];
			char boneId;
			unsigned char referenceCount;
			char boneIds[3];
			unsigned char weights[3];
			unsigned int extra;
			float renderColor[3];
		};
		struct ms3d_triangle_t
		{
			unsigned short flags;
			unsigned short vertexIndices[3];
			float vertexNormals[3][3];
			float s[3];
			float t[3];
			float normal[3];
			unsigned char smoothingGroup;
			unsigned char groupIndex;
		};
		struct ms3d_group_t
		{
			unsigned char flags;
			char name[32];
			std::vector<unsigned short> triangleIndices;
			char materialIndex;
			std::vector<char> comment;
		};
		struct ms3d_material_t
		{
			char name[32];
			float ambient[4];
			float diffuse[4];
			float specular[4];
			float emissive[4];
			float shininess;
			float transparency;
			unsigned char mode;
			char texture[MAX_TEXTURE_FILENAME_SIZE];
			char alphamap[MAX_TEXTURE_FILENAME_SIZE];
			unsigned char id;
			std::vector<char> comment;
		};
		struct ms3d_keyframe_t
		{
			float time;
			float key[3];
		};
		struct ms3d_tangent_t
		{
			float tangentIn[3];
			float tangentOut[3];
		};
		struct ms3d_joint_t
		{
			unsigned char flags;
			char name[32];
			char parentName[32];
			float rot[3];
			float pos[3];
			std::vector<ms3d_keyframe_t> rotationKeys;
			std::vector<ms3d_keyframe_t> positionKeys;
			std::vector<ms3d_tangent_t> tangents;
			std::vector<char> comment;
			float color[3];
			// used for rendering
			int parentIndex;
			float matLocalSkeleton[3][4];
			float matGlobalSkeleton[3][4];
			float matLocal[3][4];
			float matGlobal[3][4];
		};
	protected:
		bool isLoaded;

		std::vector<ms3d_vertex_t> m_vertices;
		std::vector<ms3d_triangle_t> m_triangles;
		std::vector<ms3d_group_t> m_groups;
		std::vector<ms3d_material_t> m_materials;
		float m_animationFps;
		float m_currentTime;
		int m_totalFrames;
		std::vector<ms3d_joint_t> m_joints;
		std::vector<char> m_comment;
		float m_jointSize;
		int m_transparencyMode;
		float m_alphaRef;
	public:
		classMS3DModel();
		bool LoadFromFile(const char *filename);
		void Clear();
		bool IsModelLoaded() const;

		

		const std::vector<ms3d_vertex_t> * GetPoint_m_vertices() const;
		const std::vector<ms3d_triangle_t> * GetPoint_m_triangles() const;
		const std::vector<ms3d_group_t> * GetPoint_m_groups() const;
		const std::vector<ms3d_material_t> * GetPoint_m_materials() const;
		float Get_m_animationFps() const;
		float Get_m_currentTime() const;
		int Get_m_totalFrames() const;
		const std::vector<ms3d_joint_t> * GetPoint_m_joints() const;
		const std::vector<char> * GetPoint_m_comment() const;
		float Get_m_jointSize() const;
		int Get_m_transparencyMode() const;
		float Get_m_alphaRef() const;
		
		//const classMS3DModel & operator = (const classMS3DModel & _classMS3DModelObj);
	};

}