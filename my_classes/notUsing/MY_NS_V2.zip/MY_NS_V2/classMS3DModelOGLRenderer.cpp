#include"classMS3DModelOGLRenderer.h"
#include"classMS3DModel.h"
namespace MY_NS_V2
{
	bool classMS3DModelOGLRenderer::vRender(classModel *m, float x, float y)
	{
		if (m==0) return false;
		classMS3DModel *pm=(classMS3DModel *) m;
		
		return true;
	}
}