#include"classMS3DModel.h"
#include<stdio.h>
namespace MY_NS_V2
{
	classMS3DModel::classMS3DModel()
	//: isLoaded(false)
	{
		Clear();
	}
	bool classMS3DModel::LoadFromFile(const char *filename)
	{
		Clear();

		FILE *fp=fopen(filename,"rb");
		if (!fp)
			return false;
		
		fseek(fp,0,SEEK_END);
		long fileSize=ftell(fp);
		fseek(fp,0,SEEK_SET);

		char id[10];
		fread(id,sizeof(char),10,fp);
		if (strncmp(id,"MS3D000000",10)!=0)
		{
			fclose(fp);
			// "This is not a valid MS3D file format!"
			return false;
		}

		int version;
		fread(&version,sizeof(int),1,fp);
		if (version!=4)
		{
			fclose(fp);
			// "This is not a valid MS3D file version!"
			return false;
		}

		int i, j;

		// vertices
		unsigned short numVertices;
		fread(&numVertices,sizeof(unsigned short),1,fp);
		m_vertices.resize(numVertices);
		for (i=0; i<numVertices; i++)
		{
			fread(&m_vertices[i].flags,sizeof(unsigned char),1,fp);
			fread(&m_vertices[i].vertex,sizeof(float),3,fp);
			fread(&m_vertices[i].boneId,sizeof(char),1,fp);
			fread(&m_vertices[i].referenceCount,sizeof(unsigned char),1,fp);
		}

		// triangles
		unsigned short numTriangles;
		fread(&numTriangles,sizeof(unsigned short),1,fp);
		m_triangles.resize(numTriangles);
		for (i=0; i<numTriangles; i++)
		{
			fread(&m_triangles[i].flags,sizeof(unsigned short),1,fp);
			fread(m_triangles[i].vertexIndices,sizeof(unsigned short),3,fp);
			fread(m_triangles[i].vertexNormals,sizeof(float),3*3,fp);
			fread(m_triangles[i].s,sizeof(float),3,fp);
			fread(m_triangles[i].t,sizeof(float),3,fp);
			fread(&m_triangles[i].smoothingGroup,sizeof(unsigned char),1,fp);
			fread(&m_triangles[i].groupIndex,sizeof(unsigned char),1,fp);

			// TODO: calculate triangle normal
		}

		// groups
		unsigned short numGroups;
		fread(&numGroups,sizeof(unsigned short),1,fp);
		m_groups.resize(numGroups);
		for (i=0; i<numGroups; i++)
		{	
			fread(&m_groups[i].flags,sizeof(unsigned char),1,fp);
			fread(m_groups[i].name,sizeof(char),32,fp);

			unsigned short numGroupTriangles;
			fread(&numGroupTriangles,sizeof(unsigned short),1,fp);
			m_groups[i].triangleIndices.resize(numGroupTriangles);
			if (numGroupTriangles>0)
				fread(&m_groups[i].triangleIndices[0],sizeof(unsigned short),numGroupTriangles,fp);

			fread(&m_groups[i].materialIndex,sizeof(char),1,fp);
		}

		// materials
		unsigned short numMaterials;
		fread(&numMaterials,sizeof(unsigned short),1,fp);
		m_materials.resize(numMaterials);
		for (i = 0; i<numMaterials; i++)
		{
			fread(m_materials[i].name,sizeof(char),32,fp);
			fread(&m_materials[i].ambient,sizeof(float),4,fp);
			fread(&m_materials[i].diffuse,sizeof(float),4,fp);
			fread(&m_materials[i].specular,sizeof(float),4,fp);
			fread(&m_materials[i].emissive,sizeof(float),4,fp);
			fread(&m_materials[i].shininess,sizeof(float),1,fp);
			fread(&m_materials[i].transparency,sizeof(float),1,fp);
			fread(&m_materials[i].mode,sizeof(unsigned char),1,fp);
			fread(m_materials[i].texture,sizeof(char),MAX_TEXTURE_FILENAME_SIZE,fp);
			fread(m_materials[i].alphamap,sizeof(char),MAX_TEXTURE_FILENAME_SIZE,fp);

			// set alpha
			m_materials[i].ambient[3] = m_materials[i].transparency;
			m_materials[i].diffuse[3] = m_materials[i].transparency;
			m_materials[i].specular[3] = m_materials[i].transparency;
			m_materials[i].emissive[3] = m_materials[i].transparency;
		}

		// animation
		fread(&m_animationFps,sizeof(float),1,fp);
		if (m_animationFps<1.0f)
			m_animationFps=1.0f;
		fread(&m_currentTime,sizeof(float),1,fp);
		fread(&m_totalFrames,sizeof(int),1,fp);

		// joints
		unsigned short numJoints;
		fread(&numJoints,sizeof(unsigned short),1,fp);
		m_joints.resize(numJoints);
		for (i=0; i<numJoints; i++)
		{
			fread(&m_joints[i].flags,sizeof(unsigned char),1,fp);
			fread(m_joints[i].name,sizeof(char),32,fp);
			fread(m_joints[i].parentName,sizeof(char),32,fp);
			fread(m_joints[i].rot,sizeof(float),3,fp);
			fread(m_joints[i].pos,sizeof(float),3,fp);
    
			unsigned short numKeyFramesRot;
			fread(&numKeyFramesRot,sizeof(unsigned short),1,fp);
			m_joints[i].rotationKeys.resize(numKeyFramesRot);

			unsigned short numKeyFramesPos;
			fread(&numKeyFramesPos,sizeof(unsigned short),1,fp);
			m_joints[i].positionKeys.resize(numKeyFramesPos);

			// the frame time is in seconds, so multiply it by the animation fps, to get the frames
			// rotation channel
			for (j=0; j<numKeyFramesRot; j++)
			{
				fread(&m_joints[i].rotationKeys[j].time,sizeof(float),1,fp);
				fread(&m_joints[i].rotationKeys[j].key,sizeof(float),3,fp);
				m_joints[i].rotationKeys[j].time*=m_animationFps;
			}

			// translation channel
			for (j=0; j<numKeyFramesPos; j++)
			{	
				fread(&m_joints[i].positionKeys[j].time,sizeof(float),1,fp);
				fread(&m_joints[i].positionKeys[j].key,sizeof(float),3,fp);
				m_joints[i].positionKeys[j].time*=m_animationFps;
			}
		}

		// comments
		long filePos=ftell(fp);
		if (filePos<fileSize)
		{
			int subVersion=0;
			fread(&subVersion,sizeof(int),1,fp);
			if (subVersion==1)
			{
				int numComments=0;
				size_t commentSize=0;

				// group comments
				fread(&numComments,sizeof(int),1,fp); 
				for (i=0; i<numComments; i++)
				{
					int index;
					fread(&index,sizeof(int),1,fp);
					std::vector<char> comment;
					fread(&commentSize,sizeof(size_t),1,fp);
					comment.resize(commentSize);
					if (commentSize>0)
						fread(&comment[0],sizeof(char),commentSize,fp);
					if (index>=0 && index<(int)m_groups.size())
						m_groups[index].comment=comment;
				}

				// material comments
				fread(&numComments,sizeof(int),1,fp); 
				for(i=0; i<numComments; i++)
				{
					int index;
					fread(&index,sizeof(int),1,fp);
					std::vector<char> comment;
					fread(&commentSize,sizeof(size_t),1,fp);
					comment.resize(commentSize);
					if (commentSize>0)
						fread(&comment[0],sizeof(char),commentSize,fp);
					if (index>=0 && index<(int)m_materials.size())
						m_materials[index].comment=comment;
				}

				// joint comments
				fread(&numComments,sizeof(int),1,fp); 
				for(i=0; i<numComments; i++)
				{
					int index;
					fread(&index,sizeof(int),1,fp);
					std::vector<char> comment;
					fread(&commentSize,sizeof(size_t),1,fp);
					comment.resize(commentSize);
					if (commentSize>0)
						fread(&comment[0],sizeof(char),commentSize,fp);
					if (index>=0 && index<(int)m_joints.size())
						m_joints[index].comment=comment;
				}

				// model comments
				fread(&numComments,sizeof(int),1,fp);
				if (numComments==1)
				{
					std::vector<char> comment;
					fread(&commentSize,sizeof(size_t),1,fp);
					comment.resize(commentSize);
					if (commentSize>0)
						fread(&comment[0],sizeof(char),commentSize,fp);
					m_comment=comment;
				}
			}
			else
			{
				// "Unknown subversion for comments %d\n", subVersion);
			}
		}

		// vertex extra
		filePos=ftell(fp);
		if (filePos<fileSize)
		{
			int subVersion=0;
			fread(&subVersion,sizeof(int),1,fp);
			if (subVersion==2)
			{
				for(int i=0; i<numVertices; i++)
				{
					fread(&m_vertices[i].boneIds[0],sizeof(char),3,fp);
					fread(&m_vertices[i].weights[0],sizeof(unsigned char),3,fp);
					fread(&m_vertices[i].extra,sizeof(unsigned int),1,fp);
				}
			}
			else if (subVersion==1)
			{
				for(int i=0; i<numVertices; i++)
				{
					fread(&m_vertices[i].boneIds[0],sizeof(char),3,fp);
					fread(&m_vertices[i].weights[0],sizeof(unsigned char),3,fp);
				}
			}
			else
			{
				// "Unknown subversion for vertex extra %d\n", subVersion);
			}
		}

		// joint extra
		filePos=ftell(fp);
		if (filePos<fileSize)
		{
			int subVersion=0;
			fread(&subVersion,sizeof(int),1,fp);
			if (subVersion==1)
			{
				for(int i=0; i<numJoints; i++)
				{
					fread(&m_joints[i].color,sizeof(float),3,fp);
				}
			}
			else
			{
				// "Unknown subversion for joint extra %d\n", subVersion);
			}
		}

		// model extra
		filePos=ftell(fp);
		if (filePos<fileSize)
		{
			int subVersion=0;
			fread(&subVersion,sizeof(int),1,fp);
			if (subVersion==1)
			{
				fread(&m_jointSize,sizeof(float),1,fp);
				fread(&m_transparencyMode,sizeof(int),1,fp);
				fread(&m_alphaRef,sizeof(float),1,fp);
			}
			else
			{
				//"Unknown subversion for model extra %d\n", subVersion);
			}
		}

		fclose(fp);
		isLoaded=true;
		return true;
	}
	void classMS3DModel::Clear()
	{
		m_vertices.clear();
		m_triangles.clear();
		m_groups.clear();
		m_materials.clear();
		m_animationFps=24.0f;
		m_currentTime=1.0f;
		m_totalFrames=30;
		m_joints.clear();
		m_comment.clear();
		m_jointSize=1.0f;
		m_transparencyMode=TRANSPARENCY_MODE_SIMPLE;
		m_alphaRef=0.5f;
		isLoaded=false;
	}
	bool classMS3DModel::IsModelLoaded() const
	{
		return isLoaded;
	}

	const std::vector<classMS3DModel::ms3d_vertex_t> * classMS3DModel::GetPoint_m_vertices() const
	{
		return &m_vertices;
	}
	const std::vector<classMS3DModel::ms3d_triangle_t> * classMS3DModel::GetPoint_m_triangles() const
	{
		return &m_triangles;
	}
	const std::vector<classMS3DModel::ms3d_group_t> * classMS3DModel::GetPoint_m_groups() const
	{
		return &m_groups;
	}
	const std::vector<classMS3DModel::ms3d_material_t> * classMS3DModel::GetPoint_m_materials() const
	{
		return &m_materials;
	}
	float classMS3DModel::Get_m_animationFps() const
	{
		return m_animationFps;
	}
	float classMS3DModel::Get_m_currentTime() const
	{
		return m_currentTime;
	}
	int classMS3DModel::Get_m_totalFrames() const
	{
		return m_totalFrames;
	}
	const std::vector<classMS3DModel::ms3d_joint_t> * classMS3DModel::GetPoint_m_joints() const
	{
		return &m_joints;
	}
	const std::vector<char> * classMS3DModel::GetPoint_m_comment() const
	{
		return &m_comment;
	}
	float classMS3DModel::Get_m_jointSize() const
	{
		return m_jointSize;
	}
	int classMS3DModel::Get_m_transparencyMode() const
	{
		return m_transparencyMode;
	}
	float classMS3DModel::Get_m_alphaRef() const
	{
		return m_alphaRef;
	}

	//const classMS3DModel & classMS3DModel::operator = (const classMS3DModel & _classMS3DModelObj)
	//{
	//	Clear();
	//	if (_classMS3DModelObj.IsModelLoaded())
	//	{
	//		m_vertices=*_classMS3DModelObj.GetPoint_m_vertices();
	//		m_triangles=*_classMS3DModelObj.GetPoint_m_triangles();
	//		m_groups=*_classMS3DModelObj.GetPoint_m_groups();
	//		m_materials=*_classMS3DModelObj.GetPoint_m_materials();
	//		m_animationFps=_classMS3DModelObj.Get_m_animationFps();
	//		m_currentTime=_classMS3DModelObj.Get_m_currentTime();
	//		m_totalFrames=_classMS3DModelObj.Get_m_totalFrames();
	//		m_joints=*_classMS3DModelObj.GetPoint_m_joints();
	//		m_comment=*_classMS3DModelObj.GetPoint_m_comment();
	//		m_jointSize=_classMS3DModelObj.Get_m_jointSize();
	//		m_transparencyMode=_classMS3DModelObj.Get_m_transparencyMode();
	//		m_alphaRef=_classMS3DModelObj.Get_m_alphaRef();
	//		isLoaded=true;
	//	}

	//	return *this;
	//}
}