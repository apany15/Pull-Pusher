#pragma once
//#include"../MY_NS_MESSAGE/classMessageSender.h"
namespace MY_NS_V2
{
	class classModel//: public MY_NS_MESSAGE::classMessageSender<int>
	{
	public:
		virtual bool LoadFromFile(const char *filename)=0;
		virtual void Clear()=0;
		virtual bool IsModelLoaded() const =0;
		//~classModel();
	};
}