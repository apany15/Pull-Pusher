#include"classModel.h"
#include"MY_NS_V2.h"
namespace MY_NS_V2
{
	//classModel::~classModel()
	//{
	//	this->MessageSendToAll(MESS_DIE);
	//}
}