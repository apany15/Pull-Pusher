#pragma once
#include"classModel.h"
//#include"../MY_NS_MESSAGE/classMessageReceiver.h"
//#include"../MY_NS_MESSAGE/classMessageSender.h"
namespace MY_NS_V2
{
	//template<class T_message>
	//class classMessageSender;

	class classModelRenderer//: public MY_NS_MESSAGE::classMessageReceiver<int>
	{
	//protected:
		//classModel *model;
		//virtual bool vRender(float x, float y)=0;
	public:
		//classModelRenderer(classModel *m=0);
		//void ConnectModel(classModel *m);
		//bool IsModelConnected();
		virtual bool vRender(classModel *m, float x, float y)=0;
		//virtual void MY_NS_MESSAGE::classMessageReceiver<int>::MessageReseive(int _message, MY_NS_MESSAGE::classMessageSender<int> * fromWho);
	};
}