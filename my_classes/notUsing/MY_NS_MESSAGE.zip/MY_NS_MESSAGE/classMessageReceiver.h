#pragma once
//#include"classMessageSender.h"

namespace MY_NS_MESSAGE
{
	template<class T_Message>
	class classMessageSender;

	template<class T_Message>
	class classMessageReceiver
	{
	public:
		virtual void MessageReseive(T_Message _message, classMessageSender<T_Message> * fromWho)=0;
	};
}

