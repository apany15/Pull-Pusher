#pragma once
#include"classMessageReceiver.h"
#include<vector>

namespace MY_NS_MESSAGE
{
	//class classMessageReceiver;
	template<class T_Message>
	class classMessageSender
	{	
	public:
		typedef std::vector<classMessageReceiver<T_Message> *> MyTypeArrPointReseiver;		

		classMessageSender(void);
		classMessageSender(const classMessageSender<T_Message> & _classMessageSenderObj);
		void RegMessReceiver(classMessageReceiver<T_Message> * _classMessageReceiverObj);
		virtual void UnRegAllMessReceiver();
		virtual void UnRegMessReceiver(const classMessageReceiver<T_Message> * _classMessageReceiverObj);
		void MessageSendTo(T_Message _message, const classMessageReceiver<T_Message> * _classMessageReceiverObj);
		void MessageSendToAll(T_Message _message);
		const classMessageSender &/*void*/ operator = (const classMessageSender<T_Message> & _classMessageSenderObj);
		const MyTypeArrPointReseiver * GetPointArrReceiver()const;
	protected:
		MyTypeArrPointReseiver arrReceiver;
	};
	
	//*********************************************************************
	//*********************************************************************
	//*********************************************************************
	//*************************���������� �������**************************
	//*********************************************************************
	//*********************************************************************
	//*********************************************************************


	template<class T_Message>
	classMessageSender<T_Message>::classMessageSender(void){}
	template<class T_Message>
	classMessageSender<T_Message>::classMessageSender(const classMessageSender<T_Message> & _classMessageSenderObj)
	{
		arrReceiver=_classMessageSenderObj.GetPointArrReceiver();
		//const MyTypeArrPointReseiver *tP=_classMessageSenderObj.GetPointArrReceiver();
		//unsigned int size=(unsigned int) tP->size();
		//for(unsigned int i=0; i<size; i++)
		//	arrReceiver.push_back((*tP)[i]);
	}
	template<class T_Message>
	void classMessageSender<T_Message>::RegMessReceiver(classMessageReceiver<T_Message> * _classMessageReceiverObj)
	{
		if (_classMessageReceiverObj)	
		{
			bool present=false;
			unsigned int size=(unsigned int)arrReceiver.size();
			for(unsigned int i=0; i<size; i++)
				if (arrReceiver[i]==_classMessageReceiverObj){present=true; break;}
			if (!present) arrReceiver.push_back(_classMessageReceiverObj);
		}
	}
	template<class T_Message>
	void classMessageSender<T_Message>::UnRegAllMessReceiver()
	{
		arrReceiver.clear();
	}
	template<class T_Message>
	void classMessageSender<T_Message>::UnRegMessReceiver(const classMessageReceiver<T_Message> * _classMessageReceiverObj)
	{
	
		MyTypeArrPointReseiver::iterator iter;
		MyTypeArrPointReseiver::iterator iterEnd=arrReceiver.end();
		for(iter=arrReceiver.begin(); iter!=iterEnd; iter++)
			if ((*iter)==_classMessageReceiverObj)
			{
				arrReceiver.erase(iter);
				break;
			}
	}
	template<class T_Message>
	void classMessageSender<T_Message>::MessageSendTo(T_Message _message, const classMessageReceiver<T_Message> * _classMessageReceiverObj)
	{
		unsigned int size=(unsigned int)arrReceiver.size();
		for(unsigned int i=0; i<size; i++)
			if (arrReceiver[i]==_classMessageReceiverObj) 
			{
				arrReceiver[i]->MessageReseive(_message, this);
				return;
			}

	}
	template<class T_Message>
	void classMessageSender<T_Message>::MessageSendToAll(T_Message _message)
	{
		unsigned int size=(unsigned int)arrReceiver.size();
	
		//unsigned int i=0;
		for(unsigned int i=0; i<size; i++)
			arrReceiver[i]->MessageReseive(_message, this);
	}
	template<class T_Message>
	const classMessageSender<T_Message> &/*void*/ classMessageSender<T_Message>::operator = (const classMessageSender<T_Message> & _classMessageSenderObj)
	{
		arrReceiver=*_classMessageSenderObj.GetPointArrReceiver();
		return *this;
		//arrReceiver.clear();
		//const MyTypeArrPointReseiver *tP=_classMessageSenderObj.GetPointArrReceiver();
		//unsigned int size=(unsigned int) tP->size();
		//for(unsigned int i=0; i<size; i++)
		//	arrReceiver.push_back((*tP)[i]);
	}
	template<class T_Message>
	const std::vector<classMessageReceiver<T_Message> *> * classMessageSender<T_Message>::GetPointArrReceiver()const
	{
		return &arrReceiver;
	}

}

